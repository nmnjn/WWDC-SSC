//#-hidden-code
import PlaygroundSupport

//#-end-hidden-code
/*:
# Thank You!
 
Thank you for checking out my Swift Playground!
 
I aimed to create this playground to show how we can use the power of technology to make the Internet safer and secure.
 
In the future, I aim to expand this demonstration to include image classification to identify violence, guns, nudity and other unsafe material and automatically blur those images for a safer enviroment for young kids.
 
I like solving such day to day problems using technology and expressing my passion through it.
 
*/
